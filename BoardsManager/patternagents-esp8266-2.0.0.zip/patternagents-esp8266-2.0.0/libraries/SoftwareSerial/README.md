Implementation of the Arduino software serial library for the ESP8266

Same functionality as the corresponding AVR libarary but several instances can be active at the same time.
Speed up to 115200 baud is supported. The constructor also has an optional input buffer size.

